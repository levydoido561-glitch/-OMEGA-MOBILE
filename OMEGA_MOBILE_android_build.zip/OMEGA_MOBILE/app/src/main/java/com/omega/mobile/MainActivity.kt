package com.omega.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090D12)
private val Panel = Color(0xFF111923)
private val Accent = Color(0xFF27E0A3)
private val Muted = Color(0xFF91A0AE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OmegaApp() }
    }
}

@Composable
fun OmegaApp() {
    var selectedTab by remember { mutableStateOf("HOME") }
    var espDemo by remember { mutableStateOf(false) }
    var aimDemo by remember { mutableStateOf(false) }
    var lootDemo by remember { mutableStateOf(false) }
    var fov by remember { mutableFloatStateOf(90f) }
    var distance by remember { mutableFloatStateOf(150f) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("OMEGA", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                        Text("MOBILE  •  CONTROL CENTER", color = Accent, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    Surface(color = Color(0xFF14352D), shape = RoundedCornerShape(50)) {
                        Text("DEMO MODE", color = Accent, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("HOME", "VISUAL", "AIM", "LOOT").forEach { tab ->
                        val active = selectedTab == tab
                        FilterChip(
                            selected = active,
                            onClick = { selectedTab = tab },
                            label = { Text(tab, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Accent,
                                selectedLabelColor = Bg
                            )
                        )
                    }
                }

                when (selectedTab) {
                    "HOME" -> {
                        SectionTitle("STATUS DO SISTEMA")
                        InfoCard("Build", "0.1.0 • Android", "check-circle")
                        InfoCard("Modo", "Simulador local — sem conexão com jogos", "shield-check")
                        SectionTitle("MÓDULOS")
                        ModuleCard("Visual ESP", "Elementos fictícios para teste de interface", espDemo) { espDemo = it }
                        ModuleCard("Aim Assist", "Controle de mira em simulador próprio", aimDemo) { aimDemo = it }
                        ModuleCard("Auto Loot", "Coleta demonstrativa em cenário local", lootDemo) { lootDemo = it }
                    }
                    "VISUAL" -> {
                        SectionTitle("VISUAL / ESP DEMO")
                        ModuleCard("Mostrar alvos fictícios", "Ativa marcadores apenas na tela de demonstração", espDemo) { espDemo = it }
                        SliderCard("Distância de visualização", distance, 25f..300f, "m") { distance = it }
                        DemoTargetPreview(espDemo)
                    }
                    "AIM" -> {
                        SectionTitle("AIM ASSIST — SIMULADOR")
                        ModuleCard("Assistência de mira", "Demonstração isolada; não controla Fortnite ou outros apps", aimDemo) { aimDemo = it }
                        SliderCard("Campo de visão (FOV)", fov, 20f..180f, "°") { fov = it }
                        Text("FOV selecionado: ${fov.toInt()}°", color = Muted, fontSize = 12.sp)
                    }
                    "LOOT" -> {
                        SectionTitle("LOOT — SIMULADOR")
                        ModuleCard("Coleta automática demo", "Aciona a coleta de itens fictícios neste protótipo", lootDemo) { lootDemo = it }
                        InfoCard("Baús detectados", if (lootDemo) "3 itens fictícios disponíveis" else "Aguardando ativação", "package")
                        Button(
                            onClick = { lootDemo = !lootDemo },
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg),
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (lootDemo) "PAUSAR SIMULAÇÃO" else "INICIAR SIMULAÇÃO") }
                    }
                }

                Text(
                    "OMEGA MOBILE • PROTÓTIPO LOCAL • NÃO INTERAGE COM FORTNITE",
                    color = Muted, fontSize = 9.sp, letterSpacing = 1.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 10.dp)
                )
            }
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
}

@Composable
fun InfoCard(title: String, value: String, icon: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Info, null, tint = Accent)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, color = Muted, fontSize = 11.sp)
                Text(value, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun ModuleCard(title: String, subtitle: String, enabled: Boolean, onToggle: (Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(3.dp))
                Text(subtitle, color = Muted, fontSize = 11.sp)
            }
            Switch(checked = enabled, onCheckedChange = onToggle)
        }
    }
}

@Composable
fun SliderCard(title: String, value: Float, range: ClosedFloatingPointRange<Float>, suffix: String, onChange: (Float) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(15.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text("${value.toInt()}$suffix", color = Accent, fontWeight = FontWeight.Bold)
            }
            Slider(value = value, onValueChange = onChange, valueRange = range)
        }
    }
}

@Composable
fun DemoTargetPreview(enabled: Boolean) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Box(Modifier.fillMaxWidth().height(180.dp).padding(12.dp).background(Color(0xFF080B10), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
            if (enabled) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("＋", color = Accent, fontSize = 36.sp)
                    Text("ALVO FICTÍCIO", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("Preview de interface", color = Muted, fontSize = 10.sp)
                }
            } else {
                Text("VISUALIZAÇÃO DESATIVADA", color = Muted, fontSize = 10.sp)
            }
        }
    }
}
