# OMEGA MOBILE — estrutura inicial

Protótipo Android nativo em Kotlin + Jetpack Compose, com painel de aparência flutuante/compacta.

## O que já existe
- Navegação HOME / VISUAL / AIM / LOOT
- Alternadores de módulos demonstrativos
- Sliders de FOV e distância
- Preview visual com alvo fictício
- Simulação local de coleta de itens

## Limites desta versão
Este app é um protótipo independente. Não lê a memória do Fortnite, não injeta código,
não automatiza entradas no jogo, não desenha sobre outros aplicativos e não oferece
mecanismos para contornar anticheat. Os módulos AIM, ESP e LOOT são demonstrações
dentro do próprio app.

## Como abrir
1. Instale o Android Studio.
2. Escolha **Open** e selecione a pasta `OMEGA_MOBILE`.
3. Aguarde a sincronização do Gradle.
4. Execute em um dispositivo Android ou emulador com API 26 ou superior.

## Próximas etapas sugeridas
1. Persistir as configurações com DataStore.
2. Separar UI, estado e lógica em ViewModel.
3. Criar um cenário de treino próprio com alvos e itens fictícios.
4. Adicionar testes de interface e acessibilidade.
